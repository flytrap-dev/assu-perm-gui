// Want to change colors? Navigate to -> "./custom/colors"
#include "colors.hpp"
#include "animations.h"
#include <ctime>

#define Y_PADDING 500.f

static bool animatePage(std::vector<std::string>text, std::vector<ImFont*> fonts, std::vector<_V4> colors, float& ref, bool* cond);

void ui::BeforeLoop(ID3D11Device* dvc) {
	f.RenderFonts();
	misc::set_blur(window::dx::hwnd);
	EIMAGE(dvc, __Logo, images::logo);
}

char licbuf[32];
bool rememberMe;
bool fade = false, spooferf = false, devicef;

void ui::Render() {
	static __Alpha__ alpha; alpha.render();

	misc::begin("ASSU PERM");
	{
		ImGuiWindow* window = GetCurrentWindow();

		PushFont(f.icons[0]);
		SetCursorPos({ window->Size.x - 20 - _C("a").x, 38});
		if (items::iconButton("a"))
			exit(0);
		PopFont();

		PushStyleVar(ImGuiStyleVar_Alpha, alpha.alpha);
		if (alpha.tab == tabs::login)
		{
			animatePage({ "LET'S START", "\nOUR", "\n\nJOURNEY." }, { f.montS[2], f.montM[4], f.montR[0] }, { colors::Lwhite, colors::Lwhite, colors::Main }, alpha.scroll, &alpha.startScrolling);

			draw::image(images::logo, { 8, 15 }, { 62, 27 }, colors::White, 0);

			PushFont(f.montM[3]);
			SetCursorPos({ (window->Size.x - _C("PLEASE, SIGN IN").x) / 2 ,90 - alpha.scroll + Y_PADDING });
			misc::renderMulticolorText({ "PLEASE, ", "SIGN IN" }, { f.montM[3], f.montM[3] }, { colors::Lwhite, colors::Main });
			PopFont();

			PushFont(f.montM[0]);

			PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, 26 });
			{
				SetCursorPos({ 160, 220 - alpha.scroll + Y_PADDING });
				items::input("LICENSE KEY", licbuf, _S(licbuf));

				SetCursorPosX(160);
				if (items::button("SIGN IN", { GetItemRectSize().x, 45 }))
				{
					items::sendLog("Succesfully logged in", logType::info);
					alpha.index = tabs::home;
				}
			}
			PopStyleVar(); // itemsspacing

			PopFont();
		}

		if (alpha.tab == tabs::home)
		{
			static bool scrollCheck = false;

			if (!scrollCheck)
			{
				alpha.startScrolling = false;
				alpha.scroll = 0;
				scrollCheck = true;
				fade = false;
			}
			else
			{
				animatePage({ "STAY TUNNED", "\nWITH ", "\n\t\t\tASSU." }, { f.montS[2], f.montM[4], f.montR[0] }, { colors::Lwhite, colors::Lwhite, colors::Main }, alpha.scroll, &alpha.startScrolling);

				SetCursorPos({ 20, 100 - alpha.scroll + Y_PADDING });
				misc::child("NEWS", { window->Size.x - 40, 347 });
				{
					PushFont(f.montS[1]);
					draw::text("WHAT'S NEW?", { 22, 22 }, colors::Lwhite);
					PopFont();

					PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, 50 });
					{
						//only 2 announcements, don't add more
						SetCursorPos({ 22, 77 });
						misc::announcement("Assu update 1.0 -- 06/29/2025",
							"We just release to the public! Enjoy the best & most efficient spoofing\nmethod with just a single click.");

						SetCursorPosX(22);
						misc::announcement("Assu update 0.8 -- 06/13/2025",
							"Public beta released, polishing some details just to be released.\n\t- Revamped the spoofing logic.");
					}
					PopStyleVar(); // itemspacing
				}
				EndChild();
			}
		} 
		
		if (alpha.tab == tabs::spoofer)
		{
			static bool scrollCheck = false;

			if (!scrollCheck)
			{
				alpha.startScrolling = false;
				alpha.scroll = 0;
				scrollCheck = true;
				fade = false;
			}
			else
			{
				animatePage({ "LET'S DO", "\nTHIS", "\n\nQUICK." }, { f.montS[2], f.montM[4], f.montR[0] }, { colors::Lwhite, colors::Lwhite, colors::Main }, alpha.scroll, &alpha.startScrolling);

				SetCursorPos({ 20, 100 - alpha.scroll + Y_PADDING });
				misc::child("SPOOFER", { window->Size.x - 40, 347 });
				{
					ImGuiWindow* c = GetCurrentWindow();
					PushStyleVar(ImGuiStyleVar_ItemSpacing, { 12, 12 });
					{
						PushFont(f.montM[0]);

						SetCursorPos({ 20, 20 });
						misc::child2("LOGS", { c->Size.x - 40, 190 });
						{
							PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, 8 });
							items::renderLogs();
							PopStyleVar(); // itemspacing
						}
						EndChild();

						SetCursorPosX(20);
						if (items::button("PERMANENT SPOOF", { c->Size.x - GetCursorPosX() * 2 , 45 }))
						{
							items::sendLog("Started permament spoof", logType::warn);
							items::sendLog("Spoofing completed, restart your pc", logType::success); // obv send once its completed
						}

						SetCursorPosX(20);
						if (items::button("EFI SPOOF", { GetItemRectSize().x / 2 - 6, 45 }))
						{
							items::sendLog("Started efi spoof", logType::warn);
							items::sendLog("Spoofing completed, restart your pc", logType::success); // obv send once its completed
						}

						SameLine();
						if (items::button("NETWORK SPOOF", { GetItemRectSize().x, 45 }))
						{
							items::sendLog("Started network spoof", logType::warn);
							items::sendLog("Spoofing completed, restart your pc", logType::success); // obv send once its completed
						}

						PopFont();
					}
					PopStyleVar(); // itemspacing
				}
				EndChild();
			}
		}

		if (alpha.tab == tabs::checker)
		{
			static bool scrollCheck = false;

			if (!scrollCheck)
			{
				alpha.startScrolling = false;
				alpha.scroll = 0;
				scrollCheck = true;
				fade = false;
			}
			else
			{
				animatePage({ "LET'S CHECK", "\nTHE", "\n\nHARDWARE ID." }, { f.montS[2], f.montM[4], f.montR[0] }, { colors::Lwhite, colors::Lwhite, colors::Main }, alpha.scroll, &alpha.startScrolling);

				SetCursorPos({ 20, 100 - alpha.scroll + Y_PADDING });
				misc::child("SERIALCHECKER", { window->Size.x - 40, 347 });
				{
					PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0, 13 });
					{
						PushFont(f.montM[1]);

						SetCursorPos({ 30, 30 });
						misc::serial("Motherboard Manufacturer: ", "Gigabyte Technology Co., Ltd.", serialStatus::info);

						SetCursorPosX(30);
						misc::serial("CPU Model: ", "Ryzen 5 5600X 6 Core processor", serialStatus::info);

						SetCursorPosX(30);
						misc::serial("BIOS Type: ", "American Megratrends Interanational, LLC. 4959, 02/09/2024", serialStatus::info);

						SetCursorPosX(30);
						misc::separator();

						SetCursorPosX(30);
						misc::serial("Motherboard: ", "Default String", serialStatus::changed);

						SetCursorPosX(30);
						misc::serial("CPU: ", "Unknown", serialStatus::changed);

						SetCursorPosX(30);
						misc::serial("Chassis: ", "Default String", serialStatus::unchanged);

						SetCursorPosX(30);
						misc::serial("MAC Address: ", "55:11:63:30:AF:1F", serialStatus::firstTime);

						SetCursorPosX(30);
						misc::serial("System UUID: ", "b7013d14-7e11-428d-af28-bb2d1989a854", serialStatus::firstTime);

						PopFont();
					}
					PopStyleVar(); // itemspacing
				}
				EndChild();
			}
		}

		if (alpha.tab > tabs::login)
		{
			PushStyleVar(ImGuiStyleVar_ItemSpacing, { 16, 0 });
			{
				PushFont(f.montM[1]);
				SetCursorPos({ 20, 40 - alpha.scroll + Y_PADDING });

				PushStyleVar(ImGuiStyleVar_Alpha, fade == false ? 1 : alpha.alpha);

				if (items::tab("Home", alpha.index == tabs::home))
				{
					alpha.index = tabs::home;
				}

				SameLine();
				if (items::tab("Spoofer", alpha.index == tabs::spoofer)) 
				{
					if (!spooferf)
					{
						fade = true;
						spooferf = true;
					}
					alpha.index = tabs::spoofer;
				}

				SameLine();
				if (items::tab("Device", alpha.index == tabs::checker))
				{
					if (!devicef)
					{
						fade = true;
						devicef = true;
					}
					alpha.index = tabs::checker;
				}

				draw::image(images::logo, { 302, 35 - alpha.scroll + Y_PADDING }, {62, 27}, colors::White, 0);

				PopFont();
				PopStyleVar();
			}
			PopStyleVar(); //itemspacing
		}

		if (alpha.startScrolling)
			alpha.scroll = ImLerp(alpha.scroll, Y_PADDING, xtime(4));

		PopStyleVar(); //alpha
	}
	ImGui::End();
}

static bool animatePage(std::vector<std::string>text, std::vector<ImFont*> fonts, std::vector<_V4> colors, float& ref, bool* cond)
{
	auto* window = GetCurrentWindow();

	SetCursorPosY(50 - ref);
	misc::renderTitles(text, fonts, colors);

	SetCursorPos({ (window->Size.x - 35) / 2, 255 - ref });
	if (items::buttonArrow(text[0] + "BUTTON"))
		*cond = true;

	if (ref < Y_PADDING - 20)
		return false;

	return true;
}

