#define IMGUI_DEFINE_MATH_OPERATORS
#define NOMINMAX

#pragma comment(lib, "D3DX11.lib")

#include <iostream>
#include <windows.h>
#include <d3d11.h>
#include <D3DX11tex.h>
#include <tchar.h>
#include <dwmapi.h>
#include <map>
#include <algorithm>
#include <array>
#include <vector>
#include <sstream>
#include <iomanip>

#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_freetype.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "../__ext/fonts.h"

using namespace ImGui;

/* ----------------------------DEFINES------------------------------------ */

//#define DXBG

#define _C(ARG) (CalcTextSize(ARG))
#define _CO(ARG) (GetColorU32(ARG))
#define _S(ARG) (sizeof(ARG) / sizeof(ARG[0]))

#define _V2 ImVec2
#define _V4 ImVec4
#define RGBA ImColor

#define EIMAGE(DVC, PDATA, TARGET) \
 (D3DX11CreateShaderResourceViewFromMemory(DVC, PDATA, sizeof(PDATA), nullptr, nullptr, &TARGET, nullptr))

#define EFONT(PDATA, FSIZE, CFG) \
    (io.Fonts->AddFontFromMemoryTTF(PDATA, sizeof(PDATA), FSIZE, &CFG))

/* ----------------------------------------------------------------------- */

inline float animSpeed = 8.f;
inline float vtime(float speed) noexcept { return GetIO().DeltaTime * speed; }
inline float xtime(float speed) noexcept { return speed / GetIO().Framerate; }

/* ------------------------------WINDOW----------------------------------- */

namespace window
{
    namespace ui
    {
        inline _V2 size = { 660, 500 };
        inline _V2 SizeOnChange = window::ui::size;
        inline float rounding = 2.f;
    }

    namespace dx
    {
        inline HWND hwnd;
#ifdef DXBG
        inline _V2 size = { 1200, 800 };
#else
        inline _V2 &size = window::ui::size;
#endif 
    }
}

/* ----------------------------------------------------------------------- */

/* ------------------------------RENDER----------------------------------- */

namespace ui
{
    void BeforeLoop(ID3D11Device* dvc);
    void Render();
}

/* ----------------------------------------------------------------------- */


/* ----------------------------FONTS-&-IMAGES------------------------------ */

struct Fonts {

    std::vector<float> montSSizes = { 12, 24, 30 };
    std::vector<float> montMSizes = { 14, 16, 18, 24, 30 };
    std::vector<float> montRSizes = { 30 };
    std::vector<float> iconSizes = { 18, 24 };

    std::vector<ImFont*> montS = std::vector<ImFont*>(montSSizes.size());
    std::vector<ImFont*> montM = std::vector<ImFont*>(montMSizes.size());
    std::vector<ImFont*> montR = std::vector<ImFont*>(montRSizes.size());
    std::vector<ImFont*> icons = std::vector<ImFont*>(iconSizes.size());

    ImFont* pass;
    auto RenderFonts() noexcept -> void;
}; inline Fonts f;

inline auto Fonts::RenderFonts() noexcept -> void {
    ImGuiIO& io = GetIO();
    ImFontConfig cfg;
    cfg.FontDataOwnedByAtlas = false;
    cfg.FontBuilderFlags = ImGuiFreeTypeBuilderFlags_ForceAutoHint | ImGuiFreeTypeBuilderFlags_LightHinting | ImGuiFreeTypeBuilderFlags_LoadColor;

    for (int i = 0; i < f.montSSizes.size(); i++)
        f.montS[i] = EFONT(__MontS, (f.montSSizes[i]) + 4, cfg);

    for (int i = 0; i < f.montMSizes.size(); i++)
        f.montM[i] = EFONT(__MontM, (f.montMSizes[i]) + 3, cfg);

    for (int i = 0; i < f.montRSizes.size(); i++)
        f.montR[i] = EFONT(__MontR, (f.montRSizes[i]) + 4, cfg);

    for (int i = 0; i < f.iconSizes.size(); i++)
        f.icons[i] = EFONT(__Icon, (f.iconSizes[i]), cfg);

    f.pass = EFONT(__Passw, (25), cfg);
}

namespace images {
    inline ID3D11ShaderResourceView* texture;
    inline ID3D11ShaderResourceView* logo;
}

enum tabs
{
    login,
    home,
    spoofer,
    checker
};

class __Alpha__ {
public:
    int index, tab;
    float alpha, scroll;
    bool startScrolling;

    auto render() noexcept -> bool {
        if (alpha == 0)
            tab = index;
        
        time = vtime(5);
        return alpha = std::clamp(alpha + (time * (index == tab ? 1.f : -1.f)), 0.f, 1.f);
    }
private:
    float time;
};

inline std::string getLocalTime()
{
    std::time_t time = std::time(nullptr);
    std::tm local;
    localtime_s(&local, &time);

    std::ostringstream oss;
    oss << std::put_time(&local, "%H:%M");

    return oss.str();
}