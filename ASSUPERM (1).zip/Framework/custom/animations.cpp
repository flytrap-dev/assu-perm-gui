#include "animations.h"
#define PI 3.14159265358979323846f

float __Animations__::eOutBounce(float t)
{
        float n1 = 7.5625f;
        const float d1 = 2.75f;

        if (t < 1.0f / d1) 
            return n1 * t * t;
        
        else if (t < 2.0f / d1) 
        {
            float reduced_t = t - 1.5f / d1;
            return n1 * reduced_t * reduced_t + 0.75f;
        }

        else if (t < 2.5f / d1) 
        {
            float reduced_t = t - 2.25f / d1;
            return n1 * reduced_t * reduced_t + 0.9375f;
        }

        else 
        {
            float reduced_t = t - 2.625f / d1;
            return n1 * reduced_t * reduced_t + 0.984375f;
        }
}

float __Animations__::eInOutCubic(float t)
{
    return t < 0.5 ? 4 * t * t * t : 1 - std::pow(-2 * t + 2, 3) / 2;
}

float __Animations__::eInOutElastic(float t)
{
    const float c5 = (2 * PI) / 4.5;
    return t == 0 ? 0 : t == 1 ? 1 : t < 0.5 ? -(std::pow(2, 20 * t - 10) * std::sin((20 * t - 11.125) * c5)) / 2 : (std::pow(2, -20 * t + 10) * std::sin((20 * t - 11.125) * c5)) / 2 + 1;
}

float __Animations__::eLINEAR(float t) 
{
    return t;
}
float __Animations__::eInQuad(float t) 
{
    return t * t;
}

float __Animations__::eOutQuad(float t) 
{
    return t * (2 - t);
}

float __Animations__::eInOutQuad(float t) 
{
    return t < 0.5f ? 2 * t * t : -1 + (4 - 2 * t) * t;
}
float __Animations__::eInCubic(float t) 
{
    return t * t * t;
}

float __Animations__::eOutCubic(float t) 
{
    return 1 - std::pow(1 - t, 3);
}

float __Animations__::eInQuart(float t) 
{
    return t * t * t * t;
}

float __Animations__::eOutQuart(float t) 
{
    return 1 - std::pow(1 - t, 4);
}

float __Animations__::eInOutQuart(float t) 
{
    return t < 0.5f ? 8 * t * t * t * t : 1 - std::pow(-2 * t + 2, 4) / 2;
}
float __Animations__::eInQuint(float t) 
{
    return t * t * t * t * t;
}

float __Animations__::eOutQuint(float t) 
{
    return 1 - std::pow(1 - t, 5);
}

float __Animations__::eInOutQuint(float t) 
{
    return t < 0.5f ? 16 * t * t * t * t * t : 1 - std::pow(-2 * t + 2, 5) / 2;
}

float __Animations__::eInSine(float t) 
{
    return 1 - std::cos((t * PI) / 2);
}

float __Animations__::eOutSine(float t) 
{
    return std::sin((t * PI) / 2);
}

float __Animations__::eInOutSine(float t) 
{
    return -(std::cos(PI * t) - 1) / 2;
}

float __Animations__::eInExpo(float t) 
{
    return t == 0.0f ? 0.0f : std::pow(2, 10 * t - 10);
}

float __Animations__::eOutExpo(float t) 
{
    return t == 1.0f ? 1.0f : 1 - std::pow(2, -10 * t);
}

float __Animations__::eInOutExpo(float t) 
{
    if (t == 0.0f) return 0.0f;
    if (t == 1.0f) return 1.0f;
    return t < 0.5f
        ? std::pow(2, 20 * t - 10) / 2
        : (2 - std::pow(2, -20 * t + 10)) / 2;
}

float __Animations__::eInCirc(float t) 
{
    return 1 - std::sqrt(1 - t * t);
}

float __Animations__::eOutCirc(float t) 
{
    return std::sqrt(1 - std::pow(t - 1, 2));
}

float __Animations__::eInOutCirc(float t) 
{
    return t < 0.5f
        ? (1 - std::sqrt(1 - 4 * t * t)) / 2
        : (std::sqrt(1 - std::pow(-2 * t + 2, 2)) + 1) / 2;
}

float __Animations__::eInElastic(float t) 
{
    const float c4 = (2 * PI) / 3;
    return t == 0.0f ? 0.0f : t == 1.0f ? 1.0f : -std::pow(2, 10 * t - 10) * std::sin((t * 10 - 10.75f) * c4);
}

float __Animations__::eOutElastic(float t) 
{
    const float c4 = (2 * PI) / 3;
    return t == 0.0f ? 0.0f : t == 1.0f ? 1.0f : std::pow(2, -10 * t) * std::sin((t * 10 - 0.75f) * c4) + 1;
}

float __Animations__::eInBack(float t) 
{
    const float c1 = 1.70158f;
    const float c3 = c1 + 1;
    return c3 * t * t * t - c1 * t * t;
}

float __Animations__::eOutBack(float t) 
{
    const float c1 = 1.70158f;
    const float c3 = c1 + 1;
    return 1 + c3 * std::pow(t - 1, 3) + c1 * std::pow(t - 1, 2);
}

float __Animations__::eInOutBack(float t) 
{
    const float c1 = 1.70158f;
    const float c2 = c1 * 1.525f;
    return t < 0.5f
        ? (std::pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2
        : (std::pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2;
}

float __Animations__::eInBounce(float t) 
{
    return 1 - eOutBounce(1 - t);
}

float __Animations__::eInOutBounce(float t)
{
    return t < 0.5f
        ? (1.0f - eOutBounce(1.0f - 2.0f * t)) * 0.5f
        : (1.0f + eOutBounce(2.0f * t - 1.0f)) * 0.5f;
}