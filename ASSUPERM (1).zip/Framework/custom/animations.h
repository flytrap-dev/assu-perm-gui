#pragma once
#include <iostream>
#include <map>
#include <algorithm>

#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_freetype.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

enum class Easings {
    LINEAR,
    InQuad, OutQuad, InOutQuad,
    InCubic, OutCubic, InOutCubic,
    InQuart, OutQuart, InOutQuart,
    InQuint, OutQuint, InOutQuint,
    InSine, OutSine, InOutSine,
    InExpo, OutExpo, InOutExpo,
    InCirc, OutCirc, InOutCirc,
    InElastic, OutElastic, InOutElastic,
    InBack, OutBack, InOutBack,
    InBounce, OutBounce, InOutBounce
};

class __Animations__
{
	float val;
    float eLINEAR(float t);
    float eInQuad(float t);
    float eOutQuad(float t);
    float eInOutQuad(float t);
    float eInCubic(float t);
    float eOutCubic(float t);
    float eInOutCubic(float t);
    float eInQuart(float t);
    float eOutQuart(float t);
    float eInOutQuart(float t);
    float eInQuint(float t);
    float eOutQuint(float t);
    float eInOutQuint(float t);
    float eInSine(float t);
    float eOutSine(float t);
    float eInOutSine(float t);
    float eInExpo(float t);
    float eOutExpo(float t);
    float eInOutExpo(float t);
    float eInCirc(float t);
    float eOutCirc(float t);
    float eInOutCirc(float t);
    float eInElastic(float t);
    float eOutElastic(float t);
    float eInOutElastic(float t);
    float eInBack(float t);
    float eOutBack(float t);
    float eInOutBack(float t);
    float eInBounce(float t);
    float eOutBounce(float t);
    float eInOutBounce(float t);

    float getEasing(float t, Easings type)
    {
        switch (type)
        {
        case Easings::LINEAR: return eLINEAR(t);
        case Easings::InQuad: return eInQuad(t);
        case Easings::OutQuad: return eOutQuad(t);
        case Easings::InOutQuad: return eInOutQuad(t);
        case Easings::InCubic: return eInCubic(t);
        case Easings::OutCubic: return eOutCubic(t);
        case Easings::InOutCubic: return eInOutCubic(t);
        case Easings::InQuart: return eInQuart(t);
        case Easings::OutQuart: return eOutQuart(t);
        case Easings::InOutQuart: return eInOutQuart(t);
        case Easings::InQuint: return eInQuint(t);
        case Easings::OutQuint: return eOutQuint(t);
        case Easings::InOutQuint: return eInOutQuint(t);
        case Easings::InSine: return eInSine(t);
        case Easings::OutSine: return eOutSine(t);
        case Easings::InOutSine: return eInOutSine(t);
        case Easings::InExpo: return eInExpo(t);
        case Easings::OutExpo: return eOutExpo(t);
        case Easings::InOutExpo: return eInOutExpo(t);
        case Easings::InCirc: return eInCirc(t);
        case Easings::OutCirc: return eOutCirc(t);
        case Easings::InOutCirc: return eInOutCirc(t);
        case Easings::InElastic: return eInElastic(t);
        case Easings::OutElastic: return eOutElastic(t);
        case Easings::InOutElastic: return eInOutElastic(t);
        case Easings::InBack: return eInBack(t);
        case Easings::OutBack: return eOutBack(t);
        case Easings::InOutBack: return eInOutBack(t);
        case Easings::InBounce: return eInBounce(t);
        case Easings::OutBounce: return eOutBounce(t);
        case Easings::InOutBounce: return eInOutBounce(t);
        default: return t;
        }
    }

    struct __Anim__
    {
        float time;
        bool cond, init;
    };

public:
    template<typename T>
    T animate(const std::string& id, bool callback, T start, T end, float speed, Easings type) 
    {
        static std::map<std::string, __Anim__> anims;
        auto& anim = anims[id];

        if (callback != anim.cond)
            anim.time = 0.0f;
        else
            anim.time = std::min(anim.time + 0.1f * speed, 1.0f);

        anim.cond = callback;

        if (anim.cond)
            anim.init = true;

        float t = getEasing(anim.time, type);
        float result = anim.init ? ImLerp(start, end, callback ? t : 1.0f - t) : start;

        return result;
    }

    template<>
    ImVec2 animate(const std::string& id, bool callback, ImVec2 start, ImVec2 end, float speed, Easings type) {
        static std::map<std::string, __Anim__> anims;
        auto& anim = anims[id];

        if (callback != anim.cond)
            anim.time = 0.0f;
        else
            anim.time = std::min(anim.time + 0.1f * speed, 1.0f);

        anim.cond = callback;

        if (anim.cond)
            anim.init = true;

        float t = getEasing(anim.time, type);
        ImVec2 result;

        result.x = callback ? t * (end.x - start.x) + start.x : t * (start.x - end.x) + end.x;
        result.y = callback ? t * (end.y - start.y) + start.y : t * (start.y - end.y) + end.y;
        
        ImVec2 rResult = anim.init ? result : start;

        return rResult;
    }
};

inline __Animations__ ANIMATE;