#include "colors.hpp"

namespace tabcol
{
	_V4 textC = colors::Gray;
	_V4 textHov = colors::Lwhite;
	_V4 textAct = colors::Main;
}

struct __Tab__
{
	_V4 text;
	float time;
};

auto items::tab(const std::string& label, bool cond) noexcept -> bool
{
	using namespace tabcol;

	ImGuiWindow* window = GetCurrentWindow();

	_V2 pos = window->DC.CursorPos;
	_V2 size = _C(label.c_str());

	bool r = InvisibleButton(label.c_str(), size);
	bool act = cond; bool hov = IsItemHovered();

	_V4 textcol = act ? textAct : hov ? textHov : textC;

	static std::map<std::string, __Tab__> anim;
	auto& w = anim.emplace(label, __Tab__(textcol)).first->second;

	w.time = xtime(animSpeed);
	w.text = ImLerp(w.text, textcol, w.time);

	window->DrawList->AddText(
		pos,
		_CO(w.text),
		label.c_str()
	);

	return r;
}