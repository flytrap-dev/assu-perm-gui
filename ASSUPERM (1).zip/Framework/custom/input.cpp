#include "colors.hpp"

namespace input
{
	inline _V4 line = colors::Main;
	inline _V4 lineAct = colors::Second;

	inline _V4 TextC = colors::Gray;
	inline _V4 TextAct = colors::Lwhite;
}

struct __Input__
{
	_V4 textcol, linecol, shadowcol;
	float shadow, time;
};

auto items::input(const std::string& label, char* buf, size_t bufsize) noexcept -> bool
{
	using namespace input;
	ImGuiWindow* window = GetCurrentWindow();
	ImGuiID id(window->GetID(label.c_str()));

	_V2 pos(window->DC.CursorPos);
	_V2 _size(window->Size.x - GetCursorPosX() * 2, 6);

	std::string L = "###" + label;

	PushStyleVar(ImGuiStyleVar_FramePadding, _V2(0, _size.y));
	PushStyleColor(ImGuiCol_FrameBg, colors::Transparent);
	PushStyleColor(ImGuiCol_Text, TextAct);

	_V2 size(_size.x, GetFrameHeight());

	static std::map<ImGuiID, __Input__> anim;
	__Input__& w = anim.emplace(id, __Input__(TextC, line)).first->second;

	window->DrawList->AddText(pos + _V2(0, _size.y), _CO(w.textcol), label.c_str());

	SetNextItemWidth(size.x);
	bool r = InputText(L.c_str(), buf, bufsize, 0);
	bool act((strlen(buf) != 0) || IsItemActive());

	_V4 textcol = act ? colors::Transparent : TextC;
	_V4 linecol = act ? lineAct : line;
	_V4 shadowCol = act ? lineAct : colors::Transparent;
	float shadow = act ? 15 : 0;

	w.time = xtime(animSpeed);
	w.textcol = ImLerp(w.textcol, textcol, w.time);
	w.linecol = ImLerp(w.linecol, linecol, w.time);
	w.shadow = ImLerp(w.shadow, shadow, w.time);
	w.shadowcol = ImLerp(w.shadowcol, shadowCol, w.time);

	float fact = 1;
	window->DrawList->AddRectFilled(pos + _V2(0, size.y - fact * 2), pos + size - _V2(0, fact), _CO(w.linecol));
	window->DrawList->AddShadowRect(pos + _V2(0, size.y - fact * 2), pos + size - _V2(0, fact), _CO(w.shadowcol), w.shadow, {});

	PopStyleVar();
	PopStyleColor(2);

	return r;
}