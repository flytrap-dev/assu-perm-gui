#include "colors.hpp"

namespace buttoncolarrow
{
	_V4 iconC = RGBA(157, 157, 157, 255);
	_V4 iconHov = colors::Lwhite;
	_V4 border = RGBA(255, 187, 128, 255 * 0.1);
}

struct __ButtonArrow__
{
	_V4 iconcol;
	float time;
};

auto items::buttonArrow(const std::string& id) noexcept -> bool
{
	ImGuiWindow* window = GetCurrentWindow();
	using namespace buttoncolarrow;

	PushFont(f.icons[1]);

	_V2 pos = window->DC.CursorPos;
	_V2 size = { 35, 50 };
	_V2 iconSize = _C("b");

	bool r = InvisibleButton(id.c_str(), size);
	bool hov = IsItemHovered();

	_V4 iconcol = hov ? iconHov : iconC;

	static std::map<std::string, __ButtonArrow__> anim;
	auto& w = anim.emplace(id, __ButtonArrow__(iconcol)).first->second;

	w.time = xtime(animSpeed) * 2;
	w.iconcol = ImLerp(w.iconcol, iconcol, w.time);

	window->DrawList->AddRectFilled(
		pos,
		pos + size,
		_CO(colors::itemBg),
		100
	);

	window->DrawList->AddRect(
		pos,
		pos + size,
		_CO(border),
		100
	);

	window->DrawList->AddText(
		pos + (size - iconSize) / 2 + _V2(0, 2),
		_CO(w.iconcol),
		"b"
	);

	PopFont();

	if (hov)
		SetMouseCursor(ImGuiMouseCursor_Hand);

	return r;
}

struct __Button__ 
{
	_V4 bgcol, textcol;
	bool clicked;
	float circlerad, time;
};

namespace buttoncol 
{
	float rounding = 0;

	_V4 bgCol = colors::Main;
	_V4 bgHov = colors::Second;
	_V4 bgAct = colors::Main;

	_V4 textC = RGBA(11, 11, 11, 255);
	_V4 textHov = RGBA(11, 11, 11, 255);
	_V4 textAct = RGBA(6, 6, 6, 255);

	_V4 border = RGBA(255, 187, 128, 255 * 0.1);
}

auto items::button(const std::string& label, const _V2& size) noexcept -> bool 
{
	using namespace buttoncol;

	ImGuiWindow* window = GetCurrentWindow();
	ImGuiID id(window->GetID(label.c_str()));

	_V2 lSize(_C(label.c_str()));
	_V2 pos = window->DC.CursorPos;

	static std::map<ImGuiID, __Button__> anim;

	bool r = InvisibleButton(label.c_str(), size);
	bool act(IsItemActive()); bool hov(IsItemHovered());

	_V4 bgcol = act ? bgAct : hov ? bgHov : bgCol;
	_V4 textcol = act ? textAct : hov ? textHov : textC;

	__Button__& w = anim.emplace(id, __Button__(bgcol, textcol)).first->second;

	w.time = xtime(animSpeed);
	w.bgcol = ImLerp(w.bgcol, bgcol, w.time);
	w.textcol = ImLerp(w.textcol, textcol, w.time);

	window->DrawList->AddRectFilled(pos,
		pos + size,
		_CO(w.bgcol),
		rounding
	);

	window->DrawList->AddText(
		pos + (size - lSize) / 2,
		_CO(w.textcol),
		label.c_str()
	);

	return r;
}