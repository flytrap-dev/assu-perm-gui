#include "colors.hpp"

struct __Logs__
{
	std::string content;
	logType type;
	_V4 color;
	float time, alpha;
	bool getTime;
};

std::vector<__Logs__> logs;

std::map<logType, _V4> logColors =
{
	{logType::success, colors::Green},
	{logType::error, colors::Red},
	{logType::warn, colors::Orange},
	{logType::info, colors::Info}
};

auto items::sendLog(std::string log, logType type) noexcept -> void
{
	logs.push_back({ log, type });
}

auto items::renderLogs() noexcept -> void
{
	ImGuiWindow* window = GetCurrentWindow();

	if (logs.size() > 8)
		logs.clear();

	for (auto& it : logs)
	{
		it.alpha = std::clamp(it.alpha + (2.f * vtime(1)), 0.f, 1.f);
		it.color = getColor(logColors, it.type);
		std::string finalString = "";

		if (!it.getTime)
		{
			finalString += "[" + getLocalTime() + "] - " + it.content;
			it.getTime = false;
		}

		PushStyleVar(ImGuiStyleVar_Alpha, it.alpha == 1 ? GetStyle().Alpha : it.alpha);
		{
			draw::text(finalString, {}, it.color);
		}
		PopStyleVar();
	}
}