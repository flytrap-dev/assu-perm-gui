#include "colors.hpp"

namespace iconcol
{
	_V4 iconC = colors::Info;
	_V4 iconAct = colors::Lwhite;
}

struct __IconButton__
{
	_V4 iconcol;
	float time;
};

auto items::iconButton(const std::string& icon) noexcept -> bool
{
	ImGuiWindow* window = GetCurrentWindow();
	using namespace iconcol;

	_V2 pos = window->DC.CursorPos;
	_V2 size = _C(icon.c_str());

	bool r = InvisibleButton(icon.c_str(), size);
	bool hov = IsItemHovered();

	_V4 col = hov ? iconAct : iconC;

	static std::map<std::string, __IconButton__> anim;
	auto& w = anim.emplace(icon, __IconButton__(iconC)).first->second;

	w.time = vtime(animSpeed) * 2;
	w.iconcol = ImLerp(w.iconcol, col, w.time);

	window->DrawList->AddText(
		pos,
		_CO(w.iconcol),
		icon.c_str()
	);

	return r;
}